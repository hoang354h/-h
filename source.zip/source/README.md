# discord-selfbot-owo-bot

**Keep In Mind This Repository Is For Educational Purposes Only. Selfbot are against Discord's ToS and against OwO's Rules! Use It At Your Own Risk!**


* ### [Download Lastest Release](https://github.com/ahihiyou20/discord-selfbot-owo-bot/tags)
[![GitHub issues](https://img.shields.io/github/issues/ahihiyou20/discord-selfbot-owo-bot?label=Open%20%C4%B0ssues)](https://github.com/ahihiyou20/discord-selfbot-owo-bot/issues)
[![GitHub forks](https://img.shields.io/github/forks/ahihiyou20/discord-selfbot-owo-bot)](https://github.com/ahihiyou20/discord-selfbot-owo-bot/network)
[![GitHub stars](https://img.shields.io/github/stars/ahihiyou20/discord-selfbot-owo-bot)](https://github.com/ahihiyou20/discord-selfbot-owo-bot/stargazers)


# How to setup?

**Using Exe Methods:**

**Open Folder Named "main". You Will See A File Named "Auto.exe", Open It And Use Without Any Bonus Setup**

**Using Python Methods:**

**Open Folder Named "source". Open A Cmd And Type:**

```
py -m pip install -r requirements.txt
```

**Then Run main.py, That's All :)**

**Or Just Normally Run main.py And It Will Automatically Install Requirements Package For You**

**Then Run "main.py", Enter Your Token And Channel ID And Other Settings. If You Don't Know How To Get Channel ID: https://support.discord.com/hc/en-us/articles/206346498-Kullan%C4%B1c%C4%B1-Sunucu-Mesaj-ID-sini-Nerden-Bulurum-**

**You Can Use This Bot On Windows, Linux And Android With "Termux" App.**

**Install Termux If You Want To Use This Bot On Android And Use Those Command ^^**:

**Termux Website: https://termux.com/**


**All Available Settings:**

**> SM (YES or NO) = Sometimes Your Bot Can Sleep To Avoid OwO's Captcha If You Turn This On.**

**> GM (YES or NO) = If You Turn This On Then Your Bot Will Automatically Use Strongest Gems.**

**> PM (YES or NO) = Enable This Will Result Your Bot Automatically Send Pray.**

**> EM (YES or NO) = Send Random Text Sometimes To Level Up If You Turn It On.**

**> Sent Captcha Alert To Discord Webhook And Ping The User**


**And Much More Features**


**Your Account Must Have A Valid OwO Profile Already, This Bot Can't Run Efficiency On New Generated Accounts.**

**You Need A Team (Army) And Some Gems Before Start Botting, That's Because This Bot cant' Build A Perfect Account From Zero Yet.**

**Feel Free To Open Issue On Github!**

**Lastest version: See in version.txt**

**Note: This Repository Is Under GNU General Public License v3.0! Please Don't Use This Repository To Sell Or Else I Will Kill You.**

**Note 2: This Repository Is For Educational Purposes Only. Selfbot are against Discord's ToS and against OwO's Rules! Use It At Your Own Risk!**
